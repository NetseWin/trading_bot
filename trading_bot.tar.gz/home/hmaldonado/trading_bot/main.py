from services.binance_api import BinanceAPI
from strategies.moving_average import moving_average_strategy
from strategies.rsi import rsi_strategy
from strategies.macd import macd_strategy
from strategies.bollinger_bands import bollinger_strategy
from services.order_manager import OrderManager
from data.data_manager import log_simulated_trade
import pandas as pd
import time
from utils.logger import main_logger
import csv

def calculate_operable_quantity(balance, price, fee_rate=0.001, precision=4, min_notional=10, percentage=0.5):
    """Calcula la cantidad máxima operable basada en el saldo disponible y el filtro de notional."""
    max_quantity = (balance * percentage) / (price * (1 + fee_rate))
    # Asegurarse de cumplir con el valor mínimo notional
    if max_quantity * price < min_notional:
        return 0  # No operable si no cumple con el filtro
    return round(max_quantity, precision)

def meets_expected_margin(buy_price, sell_price, fee_rate=0.001, min_margin=0.005):
    """Evalúa si la diferencia de precios entre compra y venta cumple con el margen esperado."""
    net_gain = (sell_price - buy_price) / buy_price  # Diferencia porcentual
    return net_gain > (min_margin + 2 * fee_rate)  # Considerar comisiones ida y vuelta

def initial_market_analysis(api, symbol, interval):
    """Realiza un análisis inicial del mercado antes de comenzar a operar."""
    try:
        candles = api.client.get_klines(symbol=symbol, interval=interval, limit=100)
        df = pd.DataFrame(candles, columns=['OpenTime', 'Open', 'High', 'Low', 'Close', 'Volume',
                                            'CloseTime', 'QuoteAssetVolume', 'Trades',
                                            'TBBAV', 'TBQAV', 'Ignore'])
        df['Close'] = df['Close'].astype(float)
        main_logger.info("Análisis inicial del mercado completado.")
        return df
    except Exception as e:
        main_logger.error(f"Error al obtener datos iniciales del mercado: {e}")
        return None

def record_transaction(transaction_type, symbol, quantity, price, total, order_id):
    """Registra una transacción en un archivo CSV."""
    file_name = "transaction_history.csv"
    fields = ['type', 'symbol', 'quantity', 'price', 'total', 'order_id', 'timestamp']

    try:
        # Verificar si el archivo existe, si no, crearlo con encabezados
        try:
            with open(file_name, 'x', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fields)
                writer.writeheader()
        except FileExistsError:
            pass

        # Registrar la transacción
        with open(file_name, 'a', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writerow({
                'type': transaction_type,
                'symbol': symbol,
                'quantity': quantity,
                'price': price,
                'total': total,
                'order_id': order_id,
                'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
            })
    except Exception as e:
        main_logger.error(f"Error al registrar transacción: {e}")

def calculate_profit(symbol, quantity_sold, sell_price):
    """Calcula la ganancia/pérdida neta para una venta basada en el historial de transacciones."""
    file_name = "transaction_history.csv"
    try:
        with open(file_name, 'r') as f:
            reader = csv.DictReader(f)
            purchases = [row for row in reader if row['type'] == 'BUY' and row['symbol'] == symbol]

        # Calcular el costo promedio de la cantidad vendida
        remaining_quantity = quantity_sold
        total_cost = 0

        for purchase in purchases:
            purchase_qty = float(purchase['quantity'])
            purchase_price = float(purchase['price'])

            if remaining_quantity <= 0:
                break

            if purchase_qty <= remaining_quantity:
                total_cost += purchase_qty * purchase_price
                remaining_quantity -= purchase_qty
            else:
                total_cost += remaining_quantity * purchase_price
                remaining_quantity = 0

        if remaining_quantity > 0:
            main_logger.warning("No hay suficientes compras registradas para calcular el costo promedio.")
            return None

        total_revenue = quantity_sold * sell_price
        profit = total_revenue - total_cost

        return profit

    except FileNotFoundError:
        main_logger.warning("Archivo de historial de transacciones no encontrado. No se puede calcular la ganancia.")
        return None
    except Exception as e:
        main_logger.error(f"Error al calcular ganancia: {e}")
        return None

def main():
    symbol = "ETHUSDT"
    interval = "1m"  # Intervalo para datos históricos
    short_window = 5  # Ventana para SMA corta (puede ser ajustado dinámicamente)
    long_window = 10  # Ventana para SMA larga (puede ser ajustado dinámicamente)
    rsi_window = 14  # Ventana para RSI (puede ser ajustado dinámicamente)
    fee_rate = 0.001  # Tasa de comisión estimada
    precision = 4  # Precisión requerida para ETH/USDT
    min_notional = 10  # Valor mínimo notional para órdenes en Binance
    percentage = 0.5  # Porcentaje del saldo disponible a usar
    min_margin = 0.005  # Margen mínimo esperado (0.5%)

    main_logger.info("Iniciando el bot de trading...")

    api = BinanceAPI()
    order_manager = OrderManager()

    # Análisis inicial del mercado
    market_data = initial_market_analysis(api, symbol, interval)
    if market_data is None:
        main_logger.error("No se pudo obtener datos del mercado. Finalizando el bot.")
        return

    while True:
        try:
            # Obtén datos históricos
            candles = api.client.get_klines(symbol=symbol, interval=interval, limit=100)
            df = pd.DataFrame(candles, columns=['OpenTime', 'Open', 'High', 'Low', 'Close', 'Volume',
                                                'CloseTime', 'QuoteAssetVolume', 'Trades',
                                                'TBBAV', 'TBQAV', 'Ignore'])
            df['Close'] = df['Close'].astype(float)

            # Aplica estrategias
            df = moving_average_strategy(df, short_window, long_window)
            df = rsi_strategy(df, rsi_window)
            df = macd_strategy(df)
            df = bollinger_strategy(df)

            # Obtén los datos más recientes
            latest_price = df['Close'].iloc[-1]
            sma_short = df['SMA_Short'].iloc[-1]
            sma_long = df['SMA_Long'].iloc[-1]
            rsi = df['RSI'].iloc[-1]
            macd = df['MACD'].iloc[-1]
            signal_line = df['Signal_Line'].iloc[-1]
            upper_band = df['Upper_Band'].iloc[-1]
            lower_band = df['Lower_Band'].iloc[-1]

            # Lógica de señales combinadas
            buy_signal = (
                df['Buy_Signal'].iloc[-1] or  # Señal de RSI o Bollinger
                (df['Signal'].iloc[-1] and macd > signal_line)  # Cruce alcista MACD
            )
            sell_signal = (
                df['Sell_Signal'].iloc[-1] or  # Señal de RSI o Bollinger
                (df['Signal'].iloc[-1] and macd < signal_line)  # Cruce bajista MACD
            )

            # Registro de análisis
            main_logger.info(
                f"Último precio: {latest_price:.2f}, SMA_Corta: {sma_short:.2f}, SMA_Larga: {sma_long:.2f}, "
                f"RSI: {rsi:.2f}, MACD: {macd:.2f}, Signal_Line: {signal_line:.2f}, "
                f"Upper_Band: {upper_band:.2f}, Lower_Band: {lower_band:.2f}"
            )

            # Verificar saldo disponible
            balances = api.get_account_balance()
            usdt_balance = balances.get('USDT', 0)
            eth_balance = balances.get('ETH', 0)

            if usdt_balance == 0 and eth_balance == 0:
                main_logger.warning("No hay saldo disponible para operar. Esperando próxima iteración.")
                time.sleep(60)
                continue

            # Determinar cantidad dinámica basada en saldo
            quantity_buy = calculate_operable_quantity(usdt_balance, latest_price, fee_rate, precision, min_notional, percentage)
            quantity_sell = calculate_operable_quantity(eth_balance * latest_price, latest_price, fee_rate, precision, min_notional, percentage)

            # Evaluar margen esperado antes de operar
            if buy_signal and quantity_buy > 0:
                main_logger.info(f"🔔 ¡Alerta de COMPRA detectada! Intentando comprar {quantity_buy} ETH a {latest_price:.2f}")
                response = order_manager.place_market_order(symbol, 'BUY', quantity_buy)
                if response:
                    total_cost = quantity_buy * latest_price
                    record_transaction('BUY', symbol, quantity_buy, latest_price, total_cost, response['orderId'])
                    main_logger.info(f"Compra registrada: {response}")

            elif sell_signal and quantity_sell > 0:
                main_logger.info(f"🔔 ¡Alerta de VENTA detectada! Intentando vender {quantity_sell} ETH a {latest_price:.2f}")
                response = order_manager.place_market_order(symbol, 'SELL', quantity_sell)
                if response:
                    total_revenue = quantity_sell * latest_price
                    profit = calculate_profit(symbol, quantity_sell, latest_price)
                    record_transaction('SELL', symbol, quantity_sell, latest_price, total_revenue, response['orderId'])
                    main_logger.info(f"Venta registrada: {response}")
                    if profit is not None:
                        main_logger.info(f"Ganancia/Pérdida neta: {profit:.2f} USDT")

            else:
                main_logger.info("Sin señales claras en este momento.")

            # Espera antes de la próxima iteración
            time.sleep(60)

        except Exception as e:
            main_logger.error(f"Error en el bot: {e}")

if __name__ == "__main__":
    main()






