# Configuración del bot
API_KEY = "VTLt4xMKN15RAExut7HrSxRYNieF7mG2bjHezLo0niRxgS9yloEWWIhPWjHpuujn"
SECRET_KEY = "tOHHMTbDEbWdC19vvxpcFXClxk12EMQtXZTbndUUnPAsseCnTgG1WchKJIVgbjkE"

# Configuraciones de trading
TRADE_SYMBOL = "ETHUSDT"  # Par de mercado
TRADE_QUANTITY = 0.001     # Cantidad fija para operar